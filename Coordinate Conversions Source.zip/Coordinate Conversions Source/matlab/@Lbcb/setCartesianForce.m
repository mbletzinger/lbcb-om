function  setCartesianForce(me,cart)

end
